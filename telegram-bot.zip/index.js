
const TelegramBot = require('node-telegram-bot-api');
const token = '8028369926:AAFB4RBoyCIswVxStyFPQMrpolWhCOeDoR0';
const bot = new TelegramBot(token, { polling: true });

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Hello! Your bot is working fine.');
});
